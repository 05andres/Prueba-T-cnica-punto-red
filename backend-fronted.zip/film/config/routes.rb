Rails.application.routes.draw do
  resources :film
end
