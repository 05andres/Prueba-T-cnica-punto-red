class CreateFilms < ActiveRecord::Migration[7.1]
  def change
    create_table :films do |t|
      t.string :title
      t.string :description
      t.string :year
      t.string :rental_duration
      t.string :rating
      t.string :duration
      t.string :rental_price

      t.timestamps
    end
  end
end
