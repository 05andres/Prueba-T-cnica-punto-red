import http from "@/http/http"


const tasks = () => {
    const task = async (payload: any) => {
        try {
        const response = await http().post("task-notication", payload)
        console.log(response)
        return {ok: true}
        } catch (error) {
        console.log(error)
        return {ok: false}
        }

    }

    return{
        task
    }

}

export default tasks