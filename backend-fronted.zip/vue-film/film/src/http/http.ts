import axios from "axios";
export const API_URL = 'http://127.0.0.1:3000/'


// https://axios-http.com/docs/interceptors TODO make interceptor when token es expired

export default function http() {
  const config: any = {
    baseURL: API_URL
  }
    return axios.create(config);

}