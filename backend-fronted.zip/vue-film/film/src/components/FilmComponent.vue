<template>
  <div class="films">
    <h1>Películas</h1>
    <div>
      <h2>{{ editingFilm ? 'Editar Película' : 'Agregar Película' }}</h2>
      <form @submit.prevent="saveFilm">
        <label for="title">Título:</label>
        <input type="text" v-model="film.title" required>
        <label for="description">Descripción:</label>
        <textarea v-model="film.description"></textarea>
        <label for="year">Año:</label>
        <input type="text" v-model="film.year">
        <label for="rental_duration">Duración de la renta:</label>
        <input type="number" v-model="film.rental_duration">
        <label for="rating">Rating:</label>
        <input type="number" v-model="film.rating">
        <label for="duration">Duración:</label>
        <input type="number" v-model="film.duration">
        <label for="rental_price">Precio de renta:</label>
        <input type="number" v-model="film.rental_price">
        <button type="submit">{{ editingFilm ? 'Actualizar' : 'Guardar' }}</button>
      </form>
    </div>
    <ul>
      <li v-for="film in films" :key="film.id">
        {{ film.title }} - Director: {{ film.director }} - Duración: {{ film.duration }}
        <button @click="showMovieStores(film.id)">Ver Tiendas</button>
        <button @click="editFilm(film)">Editar</button>
        <button @click="deleteFilm(film.id)">Eliminar</button>
      </li>
    </ul>
    <div v-if="stores.length">
      <h2>Tiendas de "{{ selectedFilm.title }}"</h2>
      <ul>
        <li v-for="store in stores" :key="store.address">
          {{ store.address }} - Cantidad de películas: {{ store.quantity }}
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
import { onMounted, ref } from 'vue'
import http from "../http/http.ts"

export default {
  setup(){
    const films = ref([]);
    const stores = ref([]);
    const film = ref({
      title: "",
      description: "",
      year: "",
      rental_duration: "",
      rating: "",
      duration: "",
      rental_price: "",
    })

    

    const fetchFilms = async () => {
      try {
        const response = await http().get("film");
        films.value = response.data;
      } catch (error) {
        console.error("Error fetching films:", error);
      }
    };

    onMounted(() => {fetchFilms});

    const saveFilmPath = async (payload) => {
      try {
        const response = await http().post("film", payload)
        console.log(response)
        return {ok: true}
      } catch (error) {
        console.log(error)
        return {ok: false}
      }
    }

    const saveFilm = async() =>{
      let payload = {
        title: film.value.title,
        description: film.value.description,
        year:film.value.year,
        rental_duration: film.value.rental_duration,
        rating: film.value.rating,
        duration: film.value.duration,
        rental_price: film.value.title
      }
       await saveFilmPath(payload).then(
        response => {
          const data = response.data
          console.log(data)
          fetchFilms(); // Actualizar la lista de películas después de guardar
        }
      ).catch(
        error => {
          console.log(error.response.data)
        }
      )
    }

    const editFilm = (filmToEdit) => {
      film.value = { ...filmToEdit };
      // Añadir lógica para editar película
    };

    const deleteFilm = (id) => {
     console.log(id)
    };

    const showMovieStores = (id) => {
      console.log(id)
    };

    return{
      films,
      stores,
      film,
      saveFilm,
      fetchFilms,
      editFilm,
      deleteFilm,
      showMovieStores
    }
  }
}
</script>

<style scoped>
/* Estilos específicos del componente */
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>